// import {render,screen} from '@testing-library/react';
// import { loginUserApi } from "./apis";
// import Products from "../../components/pages/ProductsPage/Products";
// import { useSelector } from 'react-redux';

// jest.mock('./apis');
// describe('Products',()=>{
//     test('Calls the api and renders the data',async ()=>{
//         const {products}=useSelector((state.productdata));
//         const mockData=products
//         loginUserApi.mockResolvedValue(mockData);

//         render(<Products />);
//         expect(loginUserApi).toHaveBeenCalledTimes(1);
//     })
// })
